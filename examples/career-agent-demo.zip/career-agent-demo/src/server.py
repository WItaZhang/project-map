"""Tools for the synthetic career agent."""
from mcp.server.fastmcp import FastMCP
from scoring import score

mcp = FastMCP("career")

@mcp.tool()
def search_jobs(query: str) -> list:
    """根据关键词返回职位候选。"""
    return []

@mcp.tool()
def rank_jobs(jobs: list) -> list:
    """根据已有规则为候选职位排序。"""
    return sorted(jobs, key=score, reverse=True)

@mcp.tool()
def draft_application(job_id: str) -> dict:
    """准备申请草稿，等待用户检查。"""
    return {"job_id": job_id, "status": "draft"}
