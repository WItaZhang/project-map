"""Deterministic scoring for the example."""
def score(job: dict) -> int:
    return len(job.get("matched_skills", []))
