---
name: discover-jobs
description: 搜索职位并根据偏好生成候选清单。此项目为合成示例。
---
# 发现职位
使用 `search_jobs(query)` 收集候选，再使用 `rank_jobs(jobs)` 排序。
候选清单准备好后，参考 `.claude/skills/prepare-application/SKILL.md`。
