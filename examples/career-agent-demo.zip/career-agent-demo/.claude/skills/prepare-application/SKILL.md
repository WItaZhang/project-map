---
name: prepare-application
description: 根据职位生成申请材料草稿，交由用户检查。
---
# 准备申请
使用 `draft_application(job_id)` 准备草稿。
交给 `application-reviewer` 检查材料。
